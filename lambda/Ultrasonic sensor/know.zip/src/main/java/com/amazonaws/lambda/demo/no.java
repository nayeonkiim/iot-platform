package com.amazonaws.lambda.demo;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

public class no implements RequestHandler<Object, String> {

    @Override
    public String handleRequest(Object input, Context context) {
    	context.getLogger().log("Input: " + input);
    	String json = ""+input;
    	JsonParser parser = new JsonParser();
    	JsonElement element = parser.parse(json);
    	JsonElement state = element.getAsJsonObject().get("state");
    	JsonElement reported = state.getAsJsonObject().get("reported");
    	String distance = reported.getAsJsonObject().get("distance").getAsString();//아두이노에서 잡는 distance 변수를 String 변수로 잡음
    	double dist = Double.valueOf(distance);//dist라는 double형 변수를 String변수 distance를 double형으로 변환후 저장
    	final String AccessKey="AKIA26OWOUASGAGULMBS";
    	final String SecretKey="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";
    	final String topicArn="arn:aws:sns:ap-northeast-2:752605896740:Warning_topic";
    	BasicAWSCredentials awsCreds = new BasicAWSCredentials(AccessKey, SecretKey);
    	AmazonSNS sns = AmazonSNSClientBuilder.standard()
    			.withRegion(Regions.AP_NORTHEAST_2)
    			.withCredentials( new AWSStaticCredentialsProvider(awsCreds) )
    			.build();
    	final String msg = "*Warning*\n" + "Something appears infront at" + dist + "cm";//아마존 SNS서비스 시 발송되는 이메일 문구 설정
    	final String subject = "Warning";
    	if (dist <= 12.5) {
    		PublishRequest publishRequest = new PublishRequest(topicArn, msg, subject);
    		PublishResult publishResponse = sns.publish(publishRequest);
    		}//변수 dist의 값이 12.5이하일 경우 SNS 서비스를 통해서 설정된 메일 주소로 발송
        // TODO: implement your handler
    	return subject+ "distance = " + distance + "!";
    }

}
